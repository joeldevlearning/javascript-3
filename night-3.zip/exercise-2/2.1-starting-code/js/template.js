const template = (function() { //module pattern

    let exportable = {};
    /*
    MOVIE-PROFILE.JS TEMPLATE
    */

    exportable.movieProfileFull = ( /*something?*/ ) => {
        //return something here?
    }

    return exportable;

}());