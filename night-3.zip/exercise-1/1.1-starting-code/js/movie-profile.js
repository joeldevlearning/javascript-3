/*
SUMMARY
DEPENDENCIES: omdb.js, template.js, and movie-search.js

*/
/*
PAGE LOGIC
*/

omdb.setKey('<yourkeyhere>'); //insert OMDB API key

omdb.setKey('d9429fd1');

/*Bonus TODO, how can we get the movie id dynamically from the URL hash?*/


let exampleMovie = 'tt3085312'; //hardcoded classic movie!


function getMovieProfile() {
    //TODO, get data from the promise into the webpage 
}