# 1. Meeting #1 Outline

### 1.1 - Select and manipulate single DOM elements

#### Selector options

TODO

### 1.2 - Manipulate multiple DOM elements

#### Selection

TODO

### 1.3 - Template literals for quick DOM templates

#### Selection

TODO

### 1.4 - DOM Events with individual elements

#### Listening

TODO

#### Reacting

TODO

### 1.5 - DOM events with multiple elements

#### Listening

TODO

#### Reacting

TODO

#### 



