# 2. Meeting #1 Outline

### 2.1 - Make and Keep Your Promises

#### create and pass a promise

TODO

### 2.2 - Handle if-then logic in a promise chain

#### Selection

TODO

### 2.3 - Call the fetch API and consume a promise

#### Selection

TODO

